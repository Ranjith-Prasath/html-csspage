# building-a-registration-form-with-basic-html-css
A basic html form with


here is the codepen link: https://codepen.io/sukhepadda/pen/poZjKBv
